package application;

import javafx.application.Application;



import javafx.stage.Stage;

import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Main extends Application {
	ArrayList<Sales> sales = new ArrayList<Sales>();
	ArrayList<Customers> customers = new ArrayList<Customers>();
	ArrayList<Product> products = new ArrayList<Product>();
	ArrayList<Services> services = new ArrayList<Services>();
	ArrayList<Integer> index = new ArrayList<Integer>();
	ArrayList<String> productList = new ArrayList<String>();
	ArrayList<Double> priceList = new ArrayList<Double>();
	ListView<Product> viewOrder = new ListView<Product>();

   
	Food burger = new Food("Burger", "0001-3241-ADF9", 1000, 5, 2, "gluten");
	Food hotDog = new Food("Hot Dog", "0001-9841-ADG2", 500, 3, 1, "gluten");

	Drink cokeS = new Drink("Coke\n(S)", "0002-9841-JKFN", 2, .3, "S");
	Drink cokeM = new Drink("Coke\n(M)", "0002-9841-JKFN", 2.5, .35, "M");
	Drink cokeL = new Drink("Coke\n(L)", "0002-9841-JKFN", 3, .4, "L");
	
	Drink teaS = new Drink("Tea\n(S)", "0002-9841-LJNC", 2, .1, "S");
	Drink teaM = new Drink("Tea\n(M)", "0002-9841-LJNC", 2.5, .15, "M");
	Drink teaL = new Drink("Tea\n(L)", "0002-9841-LJNC", 3, .2, "L");
	
	Drink lemonadeS = new Drink("Lemonade\n(S)", "0002-9841-WOUE", 2.5, .5, "S");
	Drink lemonadeM = new Drink("Lemonade\n(M)", "0002-9841-WOUE", 3, .55, "M");
	Drink lemonadeL = new Drink("Lemonade\n(L)", "0002-9841-WOUE", 3.5, .6, "L");

	Snack pieBlueberry = new Snack("Blueberry\nPie", "0003-9841-IFGG", 4, 1, false, false, false);
	Snack iceCream = new Snack("Ice Cream", "0003-9841-LEKF", 4, 1, false, true, false);
	Snack tapioca = new Snack("Tapioca", "0003-9841-KMJB", 4, 1, false, false, true);

	@Override
	public void start(Stage primaryStage) {
		try {

			// Product index guide:
			// burger - 0; hotdog - 1; cokeS - 2; cokeM - 3; cokeL - 4; teaS - 5; teaM - 6; teaL - 7; lemonadeS - 8; 
			// lemonadeM - 9; lemonadeL - 10; pieBlueberry - 11; iceCream - 12; tapioca - 13;
			products.add(burger);
			products.add(hotDog);
			products.add(cokeS);
			products.add(cokeM);
			products.add(cokeL);
			products.add(teaS);
			products.add(teaM);
			products.add(teaL);
			products.add(lemonadeS);
			products.add(lemonadeM);
			products.add(lemonadeL);
			products.add(pieBlueberry);
			products.add(iceCream);
			products.add(tapioca);

			// Nodes
			Label nameLabel = new Label("Enter Name:  ");
			TextField nameField = new TextField();
			Label phoneLabel = new Label("Enter Phone:  ");
			TextField phoneField = new TextField();
			Button burgerB = new Button(burger.getName());
			CheckBox sendInfo = new CheckBox("Send Info");
			sendInfo.setSelected(true);
			burgerB.setId("button");
			Button hotDogB = new Button(hotDog.getName());
			hotDogB.setId("button");
			Button cokeSB = new Button(cokeS.getName());
			cokeSB.setId("button");
			Button cokeMB = new Button(cokeM.getName());
			cokeMB.setId("button");
			Button cokeLB = new Button(cokeL.getName());
			cokeLB.setId("button");
			Button teaSB = new Button(teaS.getName());
			teaSB.setId("button");
			Button teaMB = new Button(teaM.getName());
			teaMB.setId("button");
			Button teaLB = new Button(teaL.getName());
			teaLB.setId("button");
			Button lemonadeSB = new Button(lemonadeS.getName());
			lemonadeSB.setId("button");
			Button lemonadeMB = new Button(lemonadeM.getName());
			lemonadeMB.setId("button");
			Button lemonadeLB = new Button(lemonadeL.getName());
			lemonadeLB.setId("button");
			Button pieBlueberryB = new Button(pieBlueberry.getName());
			pieBlueberryB.setId("button");
			Button iceCreamB = new Button(iceCream.getName());
			iceCreamB.setId("button");
			Button tapiocaB = new Button(tapioca.getName());
			tapiocaB.setId("button");
			Button managerMenuB = new Button("Manager\nMenu");
			managerMenuB.setId("button");
			Button submitB = new Button("Submit");
			submitB.setId("button");		
			Button cancelB = new Button("Cancel");
			cancelB.setId("button");
			
			BorderPane menu = new BorderPane();
			
			burgerB.setOnAction(event -> {
				index.add(0);
				productList.add("Burger");
				priceList.add(burger.getCost());
			
			});
			hotDogB.setOnAction(event -> {
				index.add(1);
				productList.add("Hot Dog");
				priceList.add(hotDog.getCost());
			});
			cokeSB.setOnAction(event -> {
				index.add(2);
				productList.add("Coke(S)");
				priceList.add(cokeS.getCost());
			});
			cokeMB.setOnAction(event -> {
				index.add(3);
				productList.add("Coke(M)");
				priceList.add(cokeM.getCost());
			});
			cokeLB.setOnAction(event -> {
				index.add(4);
				productList.add("Coke(L)");
				priceList.add(cokeL.getCost());
			});
			teaSB.setOnAction(event -> {
				index.add(5);
				productList.add("Tea(S)");
				priceList.add(teaS.getCost());
			});
			teaMB.setOnAction(event -> {
				index.add(6);
				productList.add("Tea(M)");
				priceList.add(teaM.getCost());
			});
			teaLB.setOnAction(event -> {
				index.add(7);
				productList.add("Tea(L)");
				priceList.add(teaL.getCost());
			});
			lemonadeSB.setOnAction(event -> {
				index.add(8);
				productList.add("Lemonade(S)");
				priceList.add(lemonadeS.getCost());
			});
			lemonadeMB.setOnAction(event -> {
				index.add(9);
				productList.add("Lemonade(M)");
				priceList.add(lemonadeM.getCost());
			});
			lemonadeLB.setOnAction(event -> {
				index.add(10);
				productList.add("Lemonade(L)");
				priceList.add(lemonadeL.getCost());
			});
			pieBlueberryB.setOnAction(event -> {
				index.add(11);
				productList.add("Blueberry Pie");
				priceList.add(pieBlueberry.getCost());
			});
			iceCreamB.setOnAction(event -> {
				index.add(12);
				productList.add("Ice Cream");
				priceList.add(iceCream.getCost());
			});
			tapiocaB.setOnAction(event -> {
				index.add(13);
				productList.add("Tapioca");
				priceList.add(tapioca.getCost());
			});
			managerMenuB.setOnAction(event -> {
				// Panes
				ListView<Sales> saleListView = new ListView<Sales>();
				saleListView.setId("order");
				saleListView.setPadding(new Insets(20));
				Button doneButton = new Button("Done");
				Button viewSalesButton = new Button("Sales");
				Button viewCustomersButton = new Button("Customers");
				Button viewProductsButton = new Button("Products");
				doneButton.setId("button");
				viewCustomersButton.setId("button");
				viewSalesButton.setId("button");
				viewProductsButton.setId("button");
				
				// Pane Properties				
				HBox managerMenu = new HBox(10, viewSalesButton, viewCustomersButton, 
											viewProductsButton, doneButton);
				managerMenu.setAlignment(Pos.CENTER);

				VBox listMenu = new VBox(10, managerMenu, saleListView);
				listMenu.setPadding(new Insets(20));
				managerMenu.setPadding(new Insets(30));
				
				// Stage
				final Stage results = new Stage();
		
				doneButton.setOnAction(e -> results.close());
				
				// Stage Properties
				results.initOwner(primaryStage);
				results.setTitle("Recorded Information(no particular order):");

				Scene resultsScene = new Scene(listMenu, 600, 600);
				resultsScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				results.sizeToScene();
				results.setScene(resultsScene);
				results.show();
			});
			submitB.setOnAction(event -> {
				
			});
			cancelB.setOnAction(event -> {
				index.clear();
				productList.clear();
				priceList.clear();
			});
	
			VBox food = new VBox(10, burgerB, hotDogB);
			VBox drinkSoda = new VBox(10, cokeSB, cokeMB, cokeLB);
			VBox drinkTea = new VBox(10, teaSB, teaMB, teaLB);
			VBox drinkLemonade = new VBox(10, lemonadeSB, lemonadeMB, lemonadeLB);
			VBox snacks = new VBox(10, pieBlueberryB, iceCreamB, tapiocaB);
			HBox menuButtons = new HBox(10, managerMenuB, submitB, cancelB);
			HBox left = new HBox(10, food, drinkSoda, drinkTea, drinkLemonade, snacks);
			HBox top = new HBox(50, nameLabel, nameField, phoneLabel, phoneField, sendInfo);
			// HBox center = new HBox(drink);
			HBox bottom = new HBox(menuButtons);
			top.setPadding(new Insets(10));
			top.setAlignment(Pos.CENTER);
			left.setAlignment(Pos.CENTER);
			bottom.setAlignment(Pos.CENTER_RIGHT);
			bottom.setPadding(new Insets(20, 200, 0, 0));
			viewOrder.setMaxWidth(500);
			viewOrder.setId("order");
			
			menu.setLeft(left);
			menu.setTop(top);
			menu.setCenter(viewOrder);
			menu.setBottom(bottom);
			menu.setPadding(new Insets(10, 10, 10, 10));
		
			
			Scene scene = new Scene(menu, 1400, 700);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			// Stage
			primaryStage.setTitle("Point of Sale");
			primaryStage.setScene(scene);

			// Show
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
