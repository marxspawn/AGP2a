package application;

public class Product {
	private String name;
	private String serialNumber;
	private double cost;
	private double expense;

	public Product(String name, String serialNumber) {
		setName(name);
		setSerialNumber(serialNumber);
	}

	public Product(String name, String serialNumber, double cost, double expense) {
		this(name, serialNumber);
		setCost(cost);
		setExpense(expense);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		// Name set to UpperCase for easier reading.
		if (name.equals("")) {
			this.name = ("NO NAME ENTERED");
		} else {
			this.name = name.toUpperCase();
		}
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		// Serial Number set to UpperCase for easier reading.
		if (serialNumber.equals("")) {
			this.serialNumber = ("NO SERIAL NUMBER ENTERED");
		} else {
			this.serialNumber = serialNumber.toUpperCase();
		}
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		if (cost >= 0) {
			this.cost = cost;
		} else {
			this.cost = 0;
		}
	}

	public double getExpense() {
		return expense;
	}

	public void setExpense(double expense) {
		if (expense >= 0) {
			this.expense = expense;
		} else {
			this.expense = 0;
		}
	}

}
