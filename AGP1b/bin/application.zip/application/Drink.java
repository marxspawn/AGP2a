package application;

public class Drink extends Product {
	private String size;
	private double mL;
	private int sugar;

	public Drink(String name, String serialNumber, double cost, double expense, String size) {
		super(name, serialNumber);
		setSize(size);
	}

	public double getmL() {
		return mL;
	}

	public int getSugar() {
		return sugar;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		// Size is put to Upper Case for ease of reading
		this.size = size.toUpperCase();
	}

}
